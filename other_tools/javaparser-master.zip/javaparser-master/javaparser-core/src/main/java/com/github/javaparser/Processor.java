/*
 * Copyright (C) 2013-2024 The JavaParser Team.
 *
 * This file is part of JavaParser.
 *
 * JavaParser can be used either under the terms of
 * a) the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 * b) the terms of the Apache License
 *
 * You should have received a copy of both licenses in LICENCE.LGPL and
 * LICENCE.APACHE. Please refer to those files for details.
 *
 * JavaParser is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 */
package com.github.javaparser;

import com.github.javaparser.ast.Node;

public class Processor {

    /**
     * Makes the parser do a post-parsing step before the result is returned to the user.
     */
    public void postProcess(ParseResult<? extends Node> result, ParserConfiguration configuration) {}

    /**
     *  Adds a pre-parsing step, which has access to the sourcecode through the innerProvider.
     */
    public Provider preProcess(Provider innerProvider) {
        return innerProvider;
    }
}
